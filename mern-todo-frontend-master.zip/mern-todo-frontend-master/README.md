# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `Go to watch the website`

https://master--earnest-taiyaki-02a284.netlify.app/

### Deployment

The frontend is deployed on netlify and the backend is deployed to heroku.
